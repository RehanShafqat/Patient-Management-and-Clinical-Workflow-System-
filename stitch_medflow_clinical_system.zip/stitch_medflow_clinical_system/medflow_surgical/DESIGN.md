```markdown
# Design System Specification: Clinical Precision & Tonal Depth

## 1. Overview & Creative North Star: "The Clinical Sanctuary"
This design system is built upon the "Clinical Sanctuary" North Star. In the high-stakes world of healthcare SaaS, we move beyond the cluttered, "utility-first" interface to create an environment of extreme calm, authoritative clarity, and intentional breathing room. 

Inspired by the precision of Linear and the refined minimalism of Vercel, this system rejects the "box-within-a-box" layout. Instead, it uses **Atmospheric Layering**—where depth is communicated through light, shadow, and tonal shifts rather than structural lines. We treat the UI as a series of sophisticated, high-end editorial surfaces that prioritize the clinician's cognitive load above all else.

---

## 2. Colors: Tonal Architecture
The palette is rooted in a deep, authoritative foundation, accented by a "Vivid Vitality" teal that guides the eye to critical actions.

### Core Palette (Material Design Mapping)
*   **Primary (`#00685f` / `#0D9488`):** The pulse of the system. Used for high-intent CTAs and active states.
*   **On-Secondary (`#131b2e` / `#0F172A`):** The "Deep Navy" anchor. Used exclusively for persistent structural elements like sidebars and headers to provide a sense of stability.
*   **Surface Tiers:**
    *   **Surface Lowest (`#ffffff`):** The "Active Card." Used for the most important interactive content.
    *   **Surface Low (`#f7f9fb` / `#F8FAFC`):** The "Standard Canvas." The primary background for the application.
    *   **Surface Container (`#eceef0` / `#F1F5F9`):** Used to "recede" secondary information or group related items.

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to section off areas. Boundaries must be defined by the shift from `surface-container-low` to `surface-container-lowest`. If you feel the need to draw a line, instead increase the padding and shift the background tone.

### Signature Textures
*   **The Teal Glow:** Active sidebar icons and primary buttons should utilize a soft outer glow (`0px 0px 12px rgba(13, 148, 136, 0.3)`).
*   **Glassmorphism:** Sticky headers must use `surface-container-lowest` at 80% opacity with a `backdrop-blur: 12px` to maintain a sense of spatial awareness as the user scrolls.

---

## 3. Typography: The Editorial Scale
We utilize **Inter** not just for legibility, but as a structural element. High contrast between Display and Body sizes creates a clear information hierarchy.

*   **Display (sm/md/lg):** 2.25rem to 3.5rem. Reserved for data dashboards and "At-a-Glance" metrics. Tight letter-spacing (-0.02em).
*   **Headline (sm/md/lg):** 1.5rem to 2rem. Used for page titles. Bold weight, high-contrast against slate backgrounds.
*   **Title (sm/md/lg):** 1rem to 1.375rem. Medium weight. Used for card headings.
*   **Body (sm/md/lg):** 0.75rem to 1rem. Regular weight. Optimized for long-form patient records with 1.6x line-height for maximum breathability.
*   **Label (sm/md):** 0.6875rem to 0.75rem. All-caps with 0.05em tracking for secondary metadata and status labels.

---

## 4. Elevation & Depth: Tonal Layering
Traditional shadows are too "heavy" for a clinical environment. We use **Ambient Depth**.

*   **The Layering Principle:** Place a `surface-container-lowest` (#FFFFFF) card on a `surface-container-low` (#F8FAFC) background. This creates a natural "lift" without a single pixel of shadow.
*   **Ambient Shadows:** When a card requires a floating state (e.g., a modal or a dragged item), use a `4%` opacity shadow of the `on-surface` color with a `32px` blur. It should feel like a soft cloud, not a dark edge.
*   **The "Ghost Border":** For input fields or containers requiring definition, use the `outline-variant` (#bcc9c6) at `15%` opacity. It should be felt, not seen.

---

## 5. Components: Precision Elements

### Buttons & CTAs
*   **Primary:** Solid Teal (`#0D9488`) with a subtle top-down gradient (Teal to Primary-Container). Roundedness: `md` (0.75rem / 12px).
*   **Secondary:** Ghost style. No background, `outline-variant` (15% opacity) border.
*   **Tertiary:** Text-only with a subtle teal hover state.

### Status Badges (The Signature Touch)
Status badges use a light tint of their functional color (Green, Amber, Red, Blue) but feature a **3px solid left-border accent** of the saturated functional color. This provides an immediate "Clinical Flag" that is accessible and premium.

### Cards & Lists
*   **The Rule of Zero Dividers:** Never use horizontal lines to separate list items. Use `16px` of vertical white space or alternating `surface-container` shifts.
*   **Border Radius:** All cards must strictly adhere to the `md` scale (12px / 0.75rem).

### Input Fields
*   **State:** Default state is a "Ghost Border" over a `surface-container-lowest` background. 
*   **Focus:** Transition the border to 100% Teal and add a `2px` soft teal outer glow.

---

## 6. Do’s and Don'ts

### Do:
*   **Embrace Asymmetry:** Use wide margins on one side of a data table to give the eye a "reset" point.
*   **Layer Surfaces:** Use the `surface` tokens to create a hierarchy of "importance stacks."
*   **Use Wide Spacing:** If a layout feels cramped, double the padding. This is a premium experience; we are not afraid of white space.

### Don’t:
*   **Use Pure Black:** Never use #000000. Use the Deep Navy (`#0F172A`) for all high-contrast text and structural elements.
*   **Use Hard Borders:** Avoid 1px solid #DDD or #CCC. They make the UI look like a legacy spreadsheet.
*   **Overuse the Glow:** The Teal glow is a "signature." If every button glows, nothing is special. Reserve it for the most critical action on the page.
*   **Stack Boxes:** Avoid putting a white card inside a white card. Use a background shift to distinguish the parent from the child.